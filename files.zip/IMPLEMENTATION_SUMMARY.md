# IMPLEMENTATION SUMMARY — Student Grade Record Management System

> **Note on this file.** The original `IMPLEMENTATION_SUMMARY.md` was not among the files provided
> for this task, so Part A below is a short baseline **reconstructed from the source code**. Part B
> documents the new work. If you have the original file, keep its content and paste Part B into it.

Legend used throughout: **[existing]** = already in the project before this task ·
**[new]** = added in this task · **[modified]** = existing code changed.

---

## Part A — Baseline (reconstructed from the source)

| Area | What was there **[existing]** |
|---|---|
| Backend (`OopFinalProj`) | `Student`, `StudentRecord`, `SubjectGrade`, `GradeRecordSystem`, and the exceptions `DuplicateStudentException`, `StudentNotFoundException`, `InvalidGradeException`. |
| Grading rules in `SubjectGrade` | Final grade = **Prelim × 0.30 + Midterm × 0.30 + Finals × 0.40** (`computeFinalGrade()`); passing mark **75.0** (`getRemarks()` → `PASSED` / `FAILED`); each component validated 0–100 (`validateGrade()`). |
| Record-level rules in `StudentRecord` | `computeGWA()` (unit-weighted average of the final grades), `getTotalUnits()`, `getPassedUnits()`, `getFailedUnits()`, `getAcademicStatus()`, `findSubject()`. |
| System rules in `GradeRecordSystem` | Duplicate student ID check, `encodeGrade()` (rejects units above the 30-unit load; returns `false` for a duplicate subject code), `updateGrades()`, `updateStudentInfo()`, `removeStudentRecord()`, search / report methods. |
| GUI | `LoginUI` (mock login `STAFF-001` / `admin123`) → `StudentGradeRecordGUI` with four tabs: **Student**, **Records**, **Grades**, **Summary**. |
| Old Grades tab | Student ID + Search, five rows of *Subject (JTextField) + Score (single JTextField)*, Average, Save / Update / Clear. A single score was copied into Prelim, Midterm **and** Finals, and every subject got 1 unit. |
| Old Summary tab | Table with `Subject 1 … Subject 5` columns showing the raw final grade of each subject, plus `Average`. |

---

## Part B — Extension: academic grading workflow

### Files changed

| File | Status |
|---|---|
| `OopFinalProj/SubjectGrade.java` | **[modified]** — additive only (+26 lines) |
| `OopFinalProj/StudentRecord.java` | **[modified]** — additive only (+5 lines) |
| `studentgraderecordoopfinalproject/GradesPanel.java` | **[modified]** |
| `studentgraderecordoopfinalproject/SummaryPanel.java` | **[modified]** |
| `studentgraderecordoopfinalproject/StudentPerformanceFrame.java` | **[new]** |
| `studentgraderecordoopfinalproject/LoginUI.java` | **[modified]** — 4 lines in the mock-data method only; the NetBeans `GEN-` blocks are untouched |
| `GradeRecordSystem`, `Student`, exceptions, `StudentPanel`, `RecordsPanel`, `StudentGradeRecordGUI` (+ `.form` files), main class | **unchanged** |

The new and rewritten panels are hand-written (no `.form`), like `StudentPanel`, `RecordsPanel`, etc., so
the Form Editor will not regenerate them.

### 1. Changes made to `SummaryPanel`

- Removed the five `Subject 1 … Subject 5` columns. The table is now
  **Student ID · Student Name · Average · Action**.
- `Average` still comes from the existing `StudentRecord.computeGWA()` (unchanged behaviour).
- New `Action` column holding the View button. Only this column is editable (so the button can be clicked);
  the other columns stay read-only.
- Tab structure, Refresh and Print buttons, red-border styling: unchanged.

### 2. The View button

- Implemented as a table cell **renderer + editor** (`ViewButtonRenderer`, `ViewButtonEditor`, inner classes
  of `SummaryPanel`), so it behaves like a real button (press animation, one click) and is styled like the
  other buttons (gray, soft-bevel border).
- On click it reads the Student ID of that row, looks the record up with the existing
  `GradeRecordSystem.findStudentById()`, and opens a `StudentPerformanceFrame`. The record is looked up at
  click time, so the window always shows current data even if the table has not been refreshed.
- Several students can be viewed side by side; each is its own window.

### 3. The student academic performance JFrame (`StudentPerformanceFrame`) **[new]**

Layout matches the main window (red banner, red-bordered titled sections, Times New Roman, gray bevel buttons).

- **Student Information:** ID, name, program, year/section, date of birth, gender, email, phone, father's and
  mother's names, address lines 1 and 2 (all already available in `Student`). Empty fields — and the
  `UNSPECIFIED` placeholder the Student tab stores for program/year/section — are shown as `N/A`.
- **Academic Performance table:** Subject (name + code) · Units · **Transmuted Grade** · Status.
  Raw Prelim / Midterm / Finals are deliberately **not** shown here.
- **Summary strip:** GWA (percentage), GWA (transmuted), overall Academic Status, Total / Passed / Failed units,
  and a one-line legend of the grading scale.
- **No grades yet:** the table is replaced by *"No grades have been recorded for this student yet."*, GWA shows
  `N/A`, status shows `NO GRADES ENCODED`, units show `0.0`. No error is thrown.
- Closing the window only disposes it (`DISPOSE_ON_CLOSE`); it does not exit the application.

### 4. Subject `JComboBox` and its predefined subjects

In `GradesPanel`, each of the five rows now has a `JComboBox` instead of a `JTextField`. First item is a
`-- Select subject --` placeholder, followed by:

| Code | Subject |
|---|---|
| OOP | Object-Oriented Programming |
| DSA | Data Structures and Algorithms |
| QM | Quantitative Methods |
| SAD | Systems Analysis and Design |
| ITD | Information Technology Development |
| DBMS | Database Management Systems |
| NET | Networking |
| WST | Web Systems and Technologies |
| HCI | Human-Computer Interaction |
| IAS | Information Assurance and Security |

- The list is a plain array of a small private class (`SubjectOption`: code, name, units) inside `GradesPanel`.
  No subject-management system was added.
- The selected option supplies the **code, name and units** of the `SubjectGrade` that is created, so the
  subject is stored in the student's record under the correct code. Every mock subject has **3.0 units**
  (the value the existing mock data in `LoginUI` already used). With the backend's 30-unit maximum load that
  allows up to 10 subjects per student.
- The mock students in `LoginUI` previously used codes `IT203` / `IT204`. They now use `OOP` / `DSA` with the
  same names as the list, so duplicate detection works between mock data and the combo box.
- If a student already has a subject that is not in the predefined list, Search adds it to that row's combo box
  so it can still be displayed and updated.

### 5. Prelim, Midterm and Finals fields

Each row now has **Prelim · Midterm · Finals** text fields (replacing the single *Score* field) and a
read-only **Transmuted** field showing the backend result for the saved grade.

Validation happens for **all rows before anything is sent to the backend**; the first problem is reported in a
dialog and the offending field receives focus. Nothing is stored if any row is invalid.

| Check | Done by |
|---|---|
| Subject chosen when scores are entered; scores present when a subject is chosen | `GradesPanel` |
| Each of the three fields required (no blanks) | `GradesPanel` |
| Must be a plain decimal number (rejects `abc`, `-5`, `NaN`, `Infinity`, `1e1`) | `GradesPanel` |
| Range 0–100 | **existing** `SubjectGrade.validateGrade()` (was unused by the GUI) |
| Same subject selected in two rows | `GradesPanel` |
| Duplicate subject for the student | see below |
| Maximum units load (30) | **existing** `GradeRecordSystem.encodeGrade()` |

The three values go straight into the existing
`new SubjectGrade(code, name, units, prelim, midterm, finals)` constructor, or into
`GradeRecordSystem.updateGrades(...)` for existing subjects. Editing a score clears that row's *Transmuted*
field until the change is saved, so a stale value is never shown.

**Save / Update behaviour**

- **Save** adds new subjects. A row that merely shows a grade that is already stored (Search pre-fills them) is
  skipped. A row for an already-stored subject with *different* values is rejected with *"… already has a
  grade for this student. Use Update to change it."* If nothing is new, it says so.
- **Update** changes existing subjects and adds subjects that are not yet recorded (this matches the old
  Update behaviour).
- **Backend finding:** `encodeGrade()` signals a duplicate by returning `false`, and the old GUI ignored that
  and still said "Grades saved." The GUI now checks it.

### 6. Backend methods and classes now connected to the GUI

| Backend member | Origin | Used for |
|---|---|---|
| `SubjectGrade.validateGrade()` | existing, previously unused by GUI | 0–100 validation of each component |
| `SubjectGrade.getRemarks()` | existing, previously unused by GUI | per-subject PASSED / FAILED |
| `SubjectGrade.getSubjectName()` / `getSubjectCode()` / `getUnits()` | existing | performance table, combo selection |
| `SubjectGrade.getPrelimGrade()` / `getMidtermGrade()` / `getFinalsGrade()` | existing | loading stored values back into the form |
| `StudentRecord.getAcademicStatus()` | existing, previously unused by GUI | overall status |
| `StudentRecord.getTotalUnits()` / `getPassedUnits()` / `getFailedUnits()` | existing, previously unused by GUI | unit totals |
| `StudentRecord.computeGWA()`, `findSubject()` | existing, already used | GWA, duplicate / update lookup |
| `GradeRecordSystem.encodeGrade()` **return value** | existing | duplicate detection (was ignored) |
| `GradeRecordSystem.encodeGrade()` / `updateGrades()` / `findStudentById()` | existing, already used | save / update / lookup |
| `SubjectGrade.getTransmutedGrade()`, `SubjectGrade.transmute()` | **new** | transmuted grades |
| `StudentRecord.computeTransmutedGWA()` | **new** | transmuted GWA |

**Existing backend deliberately *not* connected** (not part of this request): `searchByLastName`,
`searchByYearAndSection`, `searchByAcademicStatus`, `getStudentsWithFailedSubjects`, `getStudentsWithGWA`,
`computeClassAverageGWA`, `generateClassSummary`, `removeSubjectGrade`, `getFailedSubjects`, `hasRecords`.
`generateReportCard()` was also left out: it is a console-style text report that prints the raw
Prelim/Midterm/Finals columns, which the new window is specified *not* to show.

### 7. Backend modifications (all additive; no existing line was changed)

**`SubjectGrade`**
- Transmutation table as constants + `public static double transmute(double percentage)` and
  `public double getTransmutedGrade()` (= `transmute(computeFinalGrade())`).
- Constants `CONDITIONAL_PASSED_GRADE` (4.00) and `FAILED_GRADE` (5.00).

**`StudentRecord`**
- `public double computeTransmutedGWA()` = `SubjectGrade.transmute(computeGWA())`.

Nothing in the backend implemented a transmutation before, so this part had to be added; the weighting and the
passing rule were **not** touched.

### 8. Grade transmutation, academic status and GWA

**Final grade** **[existing]** — `0.30 × Prelim + 0.30 × Midterm + 0.40 × Finals` (a 0–100 percentage).

**Transmutation** **[new]** — from the table you provided, applied to the final grade. The check uses the lower
bound of each band, so values between two printed ranges (e.g. 96.495) fall in the lower band instead of
being undefined.

| Final grade | Transmuted |
|---|---|
| 96.50 – 100.00 | 1.00 |
| 93.50 – 96.49 | 1.25 |
| 90.50 – 93.49 | 1.50 |
| 87.50 – 90.49 | 1.75 |
| 84.50 – 87.49 | 2.00 |
| 81.50 – 84.49 | 2.25 |
| 78.50 – 81.49 | 2.50 |
| 75.50 – 78.49 | 2.75 |
| 75.00 – 75.49 | 3.00 |
| above 74.00 and below 75.00 | 4.00 (Conditional Passed) — see Limitations |
| 74.00 and below | 5.00 |

**Academic status** **[existing]** — per subject `SubjectGrade.getRemarks()`: `PASSED` if the final grade ≥ 75.0,
else `FAILED`. Overall: `StudentRecord.getAcademicStatus()` (`REGULAR / PASSED`, `WITH FAILED SUBJECTS`,
`NO GRADES ENCODED`).

**GWA** — `StudentRecord.computeGWA()` **[existing]**: unit-weighted average of the subjects' final grades
(percentage scale). The window shows it as *GWA (percentage)* and also its 1.00–5.00 equivalent as
*GWA (transmuted)* **[new]**, `transmute(computeGWA())`.

### 9. Testing and verification

Environment: JDK 21, headless Xvfb display. **Not run inside NetBeans itself.**

- **Compile:** the whole project compiles with no errors or warnings (`javac`, default lint).
- **Backend, boundaries:** every boundary of the table (e.g. 96.50/96.49, 75.00/74.99, 74.01/74.00) returns the
  expected grade.
- **Backend, exhaustive:** all **1,030,301** whole-number Prelim/Midterm/Finals combinations (0–100 each) were
  compared with exact `BigDecimal` arithmetic for both the PASSED/FAILED status and the transmuted grade:
  **0 mismatches** (so floating-point error does not move a grade across a band).
- **GUI, 74 automated checks, all passing,** driving the real components (button clicks, real dialogs):
  tab structure preserved · Summary has 4 columns and a View button per row · View opens the correct student ·
  per-subject transmuted grade / status / GWA / overall status are correct for the mock students · closing the
  window does not exit the app · student with no grades shows the message and `N/A` · combo contents ·
  Search fills subject, Prelim/Midterm/Finals, transmuted grade and average · all validation cases (blank,
  non-numeric, negative, `NaN`, `Infinity`, `1e1`, > 100, score without subject, same subject twice) store
  nothing · duplicate protection (different values rejected, unchanged rows skipped, original not overwritten)
  · saving a new subject while stored rows are shown · Update · backend max-units error is surfaced · Clear ·
  unknown student ID.
- Screenshots of the Grades tab, Summary tab, and the performance window (with grades, with failed subjects, and
  with no grades) were inspected visually.

### 10. Remaining limitations

1. **Conditional Passed (4.00).** The table gives no numeric range for it. It is implemented as *above 74.00 and
   below 75.00*, the only gap between "74.00 and below" and "75.00". Please confirm this is what your school
   intends. Because the existing backend status is a single 75.0 cut-off, a subject with 4.00 is labelled
   **FAILED** in the Status column. The window's legend line explains this. If 4.00 should count as passed,
   `SubjectGrade.getRemarks()` would need a (small) change.
2. **GWA definition.** The existing `computeGWA()` averages percentages, so *GWA (transmuted)* is the
   transmutation of that average, not the unit-weighted mean of the subjects' transmuted grades. The two can
   differ slightly. Switching is a few lines in `StudentRecord.computeTransmutedGWA()`.
3. **`Average` columns** in the Summary and Records tabs still show the percentage GWA (unchanged, as asked).
4. **Five subject rows** in the Grades tab (as before). A student can hold up to 10 three-unit subjects; if more
   than five exist, Search shows the first five and says so, and all of them appear in the performance window.
5. **Subject units are fixed at 3.0** for the predefined subjects (the form has no units field).
6. **Summary tab does not auto-refresh** after grades are saved; press *Refresh* (existing behaviour). The
   View window itself always reads the current record.
7. **Student tab** still stores `UNSPECIFIED` for program / year / section of newly added students (existing);
   the performance window shows these as `N/A`.
8. **Partial saves.** If the backend rejects a later row (e.g. the 30-unit limit), rows before it are already
   stored; the form reloads and the error message states how many were stored.
